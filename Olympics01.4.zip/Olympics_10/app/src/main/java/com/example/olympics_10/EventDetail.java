package com.example.olympics_10;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EventDetail extends Activity {
    private int seat;
    private String sport;
    private String discipline;
    private String category;
    private String date;
    private double startTime;
    private int duration;
    private int travelTime;
    private String vanue;


    public EventDetail(String sport,String discipline,String category,String vanue,String date,double startTime,int duration,int travelTime){
        this.sport = sport;
        this.discipline = discipline;
        this.category = category;
        this.vanue = vanue;
        this.date = date;
        this.startTime = startTime;
        this.duration = duration;
        this.travelTime = travelTime;
    }

    public String getName(){
        return sport;
    }
    public String getDetails(){
        return "VANUE:" + vanue + "\nDATE :" + date + "\nSTART TIME :" + startTime + "\nDuration :" + duration + "hrs" + "\nTravel by bus : " + travelTime + "minutes";
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventdetail);

        EventDetail swim1 = new EventDetail("Swimming","Preliminary Round", "Women","Tokyo Stadium","16.2.20",14.00,3,30);

        String a = swim1.getDetails();
        TextView out = findViewById(R.id.out);
        out.setText(a);
    }
}
