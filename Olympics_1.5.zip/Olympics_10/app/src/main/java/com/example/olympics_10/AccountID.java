package com.example.olympics_10;
import java.util.ArrayList;

public class AccountID{
    private String userID;
    private String password;
    private String card;
    private ArrayList<String> account = new ArrayList<String>();
    private String check;

    public void AccountID(String userID,String password,String card){
        this.userID = userID;
        this.password = password;
        this.card = card;
        account.add(userID);
        account.add(password);
        account.add(card);
    }

    public String Login(String userID,String password){
        for(int i=0;i<account.size();i++){
            if(account.get(0)!=userID){
                check="Please check your UserID or register";
            }
            if(account.get(1)!=password){
                check="Please check your password";
            }
        }
        return check;
    }
}
