package com.example.olympics_10;

public class Bus{
        private String type;
        private String destination;
        private double departureTime;
        private int travelTime;
        private int rows;
        private int columns;
        private int cost;


        public Bus(String type,String destination,double departureTime,int travelTime,int rows,int columns,int cost){
            this.type = type;
            this.destination = destination;               //ปลายทาง
            this.departureTime = departureTime;           //เวลาออก
            this.travelTime = travelTime;                 //เวลาเดินทางทั้งหมด
            this.rows = rows;                             //แถว
            this.columns = columns;                       //ตอน
            this.cost = cost;                             //ราคาที่นั่ง
        }
}
